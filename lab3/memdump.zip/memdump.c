#include <stdio.h>
#include "memdump.h"

void memdump( byte_t *ptr, long size ) {
  int i;
  
  // print table header
  printf("\n%-*s", ADDR_COLUMN_WIDTH, "Address");
  printf("%s", COLUMN_SEPARATOR);
  printf("%-*s", BYTE_COLUMN_WIDTH, "Bytes");
  printf("%s", COLUMN_SEPARATOR);
  printf("%-*s\n", BYTES_A_ROW, "Chars");
  
  for( i= 0; i < ADDR_COLUMN_WIDTH; i++)
    printf("-");
  printf("%s", COLUMN_SEPARATOR);
  for( i= 0; i < BYTE_COLUMN_WIDTH; i++)
    printf("-");
  printf("%s", COLUMN_SEPARATOR);
  for( i= 0; i < BYTES_A_ROW; i++)    // number of chars is char-column is exactly BYTES_A_ROW
    printf("-");
  printf("\n");
  
  /*
   * here comes your code !!!!!!!!!
   * 
   * */
  
}